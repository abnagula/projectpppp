package com.capgemini.capbook.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capbook.bean.Address;
import com.capgemini.capbook.service.IAddressService;

@RestController
@RequestMapping("/ProfileSettings")
@CrossOrigin("*")
public class AddressController {

	
	@Autowired
	private IAddressService addressService;
	

	@GetMapping("/addr")
	public ResponseEntity<List<Address>> getPassword(){
		
		List<Address> adddetails=addressService.getAllDetails();
		
		if(adddetails.isEmpty())
			return new ResponseEntity("Sorry! No Address found",HttpStatus.NOT_FOUND);
		return new ResponseEntity<List<Address>>(adddetails, HttpStatus.OK); 
	}
	
	@PostMapping("/saveAddr/{userId}")
    ResponseEntity<List<Address>> postAddress(@RequestBody Address address,@PathVariable("userId")Integer userId)	{
		List<Address> addr= addressService.saveDetails(address,userId);
				if(addr.isEmpty())
		{
			return new ResponseEntity("Sorry! unable to add address", 
					HttpStatus.NOT_FOUND); 
		}
		
		return new ResponseEntity<List<Address>>(addr, HttpStatus.OK);
	}

}
