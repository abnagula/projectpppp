package com.capgemini.capbook.bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Address {
  
	@Id
	@GeneratedValue
	private Integer addressId;
	private String doorNumber;
	private String street;
	private String locality;
	private String city;
	private String state;
	
/*	@OneToOne
	@JoinColumn(name="userId")*/
	private Integer userId;
	
	public Address() {
		
	}

	public Address(Integer addressId, String doorNumber, String street, String locality, String city, String state,
			Integer userId) {
		super();
		this.addressId = addressId;
		this.doorNumber = doorNumber;
		this.street = street;
		this.locality = locality;
		this.city = city;
		this.state = state;
		
		this.userId = userId;
	}

	public Integer getAddressId() {
		return addressId;
	}

	public void setAddressId(Integer addressId) {
		this.addressId = addressId;
	}

	public String getDoorNumber() {
		return doorNumber;
	}

	public void setDoorNumber(String doorNumber) {
		this.doorNumber = doorNumber;
	}

	public String getStreet() {
		return street;
	}

	public void setStreet(String street) {
		this.street = street;
	}

	public String getLocality() {
		return locality;
	}

	public void setLocality(String locality) {
		this.locality = locality;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	

	

	public Integer getUserId() {
		return userId;
	}

	public void setUserId(Integer userId) {
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", doorNumber=" + doorNumber + ", street=" + street + ", locality="
				+ locality + ", city=" + city + ", state=" + state + ", userId=" + userId + "]";
	}

	




}
