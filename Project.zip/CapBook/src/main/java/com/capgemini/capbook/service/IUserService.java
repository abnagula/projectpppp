package com.capgemini.capbook.service;

import java.util.List;

import com.capgemini.capbook.bean.UserProfile;

public interface IUserService {

	UserProfile getUserDetails(String email);

}
