package com.capgemini.capbook.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.apache.tomcat.util.codec.binary.Base64;
import com.capgemini.capbook.bean.ChangePassword;
import com.capgemini.capbook.bean.Email;
import com.capgemini.capbook.bean.Friend;
import com.capgemini.capbook.bean.Login;
import com.capgemini.capbook.bean.UserProfile;
import com.capgemini.capbook.dao.IEmailDao;
import com.capgemini.capbook.dao.IFriendDao;
import com.capgemini.capbook.dao.ILoginDao;
import com.capgemini.capbook.dao.IPasswdDao;
import com.capgemini.capbook.dao.IUserProfileDao;

@Service("friendservice")
public class CapBookServiceImpl implements ICapBookService{

	@Autowired
	private IFriendDao frienddao;
	@Autowired
	private IUserProfileDao userProfile;
	@Autowired
	private ILoginDao loginDao;
	@Autowired
	private IPasswdDao psswdDao;

	@Autowired
	private IEmailDao emailDao;

	private Base64 base64 = new Base64();
	@Override
	public List<Friend> saveFriend(Friend friend) {

		frienddao.save(friend);

		return frienddao.findAll();


	}

	@Override
	public List<Friend> getFriend() {

		return frienddao.findAll();


	}

	@Override
	public UserProfile saveUser(UserProfile userprofile) {
		
		
		return userProfile.save(userprofile);
	

	}

	@Override
	public List<Login> savelogin(Login login) {
		String encodedString = new String(base64.encode(login.getPassword().getBytes()));
		login.setPassword(encodedString); 
		loginDao.save(login);

		return loginDao.findAll();
	}

	@Override
	public List<ChangePassword> savepsswrd(ChangePassword changepsswd) {
		String encodedString = new String(base64.encode(changepsswd.getOldPassword().getBytes()));
		
		changepsswd.setOldPassword(encodedString);
		
		psswdDao.save(changepsswd);
		return psswdDao.findAll();
	}

	@Override
	public List<Login> getLoginDetails() {

		return loginDao.findAll();
	}

	@Override
	public List<ChangePassword> getPsswrdDetails() {


		return psswdDao.findAll();
	}

	@Override
	public List<UserProfile> getUserDetails() {
		// TODO Auto-generated method stub
		return userProfile.findAll();
	}

	@Override
	public List<Login> findByUsernameAndPassword(String email, String password) {

		List<Login> lgn=loginDao.findByUsernameAndPassword(email, password);

		return lgn;
	}

	@Override
	public String getPassword(String mail) {
		String pwd=psswdDao.getPassword(mail);
		return pwd; 
	}

	@Override
	public List<Email> saveEmaildetails(Email email) {

		
		emailDao.save(email);
		return emailDao.findAll();



	}

	@Override
	public String getMail(Integer userId) {
		return psswdDao.getMail(userId);
	}

	@Override
	public String getPsswdBymail(String mail) {
		 String psswd=psswdDao.getPassword(mail);
		String password = new String(base64.decode(psswd.getBytes()));
		System.out.println("inservice");
		return password;
	}

	@Override
	public List<ChangePassword> saveNewPwd(ChangePassword changePwd) {
		psswdDao.save(changePwd);
		return psswdDao.findAll();
	}

	/*@Override
	public Integer saveNewPasswd(String mail,String Op, String Np) {
        psswdDao.saveNewPasswd(Op, Np, mail);
		return 1;*/
	//}

	@Override
	public Integer saveLgnPasswd(String Password, String email) {
		psswdDao.saveLgnPasswd(Password, email);
			return 1;
		
		
		
	}







}
