import { Component, OnInit } from '@angular/core';
import { Address } from './address';
import { addrService } from './address.service';

@Component({
  selector: 'pm-privacy',
  templateUrl: './privacy.component.html',
  styleUrls: ['./privacy.component.css']
})
export class PrivacyComponent implements OnInit {
  public pageTitle: string = 'Welcome';
  address=new Address();


  constructor(private addrservice:addrService) { }

  ngOnInit() {
    
  }
  submit():void{
   
   this.postAddr(this.address);
 
}
postAddr(address:Address):void{
  console.log(address)
  this.addrservice.postAdd(this.address).subscribe(address=>this.address)
 
}


}
