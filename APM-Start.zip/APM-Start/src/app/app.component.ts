import { Component } from '@angular/core';
import {smsService} from './sms/sms.service';

import{loginService} from './loginpage/loginservice';
import { addrService } from './privacy/address.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers:[smsService,loginService,addrService]
})
export class AppComponent {
  title = 'capbook';
}
