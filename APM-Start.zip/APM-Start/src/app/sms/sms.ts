    export class Sms{

      msgId:number;
	  msgBody:string;
	  ReceivedDate:Date;
	  userId:number;
	  toMobileNumber:string;
    }
    
    