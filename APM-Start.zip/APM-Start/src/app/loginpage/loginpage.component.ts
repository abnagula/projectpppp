import { Component, OnInit } from '@angular/core';

import { Login } from './login';
import { loginService } from './loginservice';
import { UserProfile } from './userprofile';
import { Address } from '../privacy/address';

@Component({
  selector: 'pm-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {
  flag:boolean=false
  lName:string
  fName:string
  login:Login=new Login();
  addr=new Address();
  userprofile:UserProfile=new UserProfile();
uP:UserProfile=new UserProfile();
  Id:number;
  constructor(private lgnservice:loginService) { }
logins:UserProfile=new UserProfile();
  ngOnInit() {
  
  }
   submit():void{
    
      this.postUser();
        this.postLogin();
    this.postAdr();
    

  }
  postLogin():void{
    this.lgnservice.postLgn(this.login).subscribe(login=>this.login)
  }
  postUser():void{
    this.userprofile.userName=this.fName+this.lName
    this.login.email=this.userprofile.email;
    console.log("In post user fun")
    this.lgnservice.postuser(this.userprofile).subscribe(logins=>{console.log(this.logins);
    
      this.logins=logins;
     
      localStorage.setItem('userInfo',JSON.stringify(logins));
      alert(this.logins.userId);
      this.Id=this.logins.userId;
      alert(this.Id);
      
      //alert(this.addr.userId);
      console.log(logins);

      })
  }
  
  postAdr():void{
   this.uP=JSON.parse(localStorage.getItem("userInfo"));
    this.addr.userId=this.uP.userId;
    this.lgnservice.postAddr(this.addr).subscribe(addr=>{this.addr=addr;
    console.log(addr)})
  }


}
