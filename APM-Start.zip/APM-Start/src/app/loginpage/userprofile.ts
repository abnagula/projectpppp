import { Address } from "../privacy/address";


export class UserProfile{
     userId:number;
	 userName:string;
	 address:Address;
     isPrivateDob:boolean;
	dob:Date;
    isPrivateAreaofIntrest:boolean;
	areaofInterest:string;
     albums:any;
     isPrivategender:boolean;
	  gender:boolean;
      mobileNo:string;
	 isPrivateMobileNo:boolean;
     groups:any;
	
     status:any;
     chat:any;
	

     email:string;
	 isPrivateEmail:boolean;
	
}